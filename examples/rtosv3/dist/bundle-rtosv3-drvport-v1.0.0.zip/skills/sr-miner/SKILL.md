---
name: sr-miner
description: 从 SR 单据提取需求条目与验收条件并映射到 IR。占位：本期未实现，仅声明契约。
placeholder: true
---

# sr-miner

> **占位（placeholder）** 本技能本期未实现：正文只声明契约，不含可执行步骤；执行细节以调用它的任务书为准，禁止按本技能臆测流程。

## 用途
从 SR 单据提取需求条目、约束与验收条件，映射到 `.r2c/ir.md` 并标注来源单号。只读单据，不改业务代码。

## 何时调用
- 清单 `skills:` 白名单包含 `sr-miner`，且当前步骤需要从 SR 单据取证。

## 输入 → 输出
| 输入 | 输出 |
|---|---|
| SR 单号、`sr-fetcher-mcp` | `.r2c/sr-map.md`、需求条目清单 |

## 占位期行为
改用 agent 内置检索（读文件 / glob / 正则）完成同等取证，并在产物中标注信息来源；`--note placeholder:sr-miner`。

## 实现归属
- 未建票；实现后删除顶部占位横幅与本行。
