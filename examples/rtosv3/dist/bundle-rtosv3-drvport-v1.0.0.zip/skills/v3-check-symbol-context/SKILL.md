---
name: v3-check-symbol-context
description: 校验符号在目标上下文中的可见性与调用约束。占位：本期未实现，仅声明契约。
placeholder: true
---

# v3-check-symbol-context

> **占位（placeholder）** 本技能本期未实现：正文只声明契约，不含可执行步骤；执行细节以调用它的任务书为准，禁止按本技能臆测流程。

## 用途
校验符号在目标文件与编译单元中的可见性、重名与调用约束，返回冲突与建议。只读校验，不修改代码。

## 何时调用
- 清单 `skills:` 白名单包含 `v3-check-symbol-context`，且当前步骤需要确认符号上下文。

## 输入 → 输出
| 输入 | 输出 |
|---|---|
| 符号名与目标文件 | 上下文校验结论与冲突清单 |

## 占位期行为
改用 agent 内置检索（读文件 / glob / 正则）完成同等取证，并在产物中标注信息来源；`--note placeholder:v3-check-symbol-context`。

## 实现归属
- 未建票；实现后删除顶部占位横幅与本行。
