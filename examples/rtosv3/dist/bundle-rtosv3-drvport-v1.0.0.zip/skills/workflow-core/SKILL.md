---
name: workflow-core
description: 声明工作流核心推进规则与交付物约定。占位：本期未实现，仅声明契约。
placeholder: true
---

# workflow-core

> **占位（placeholder）** 本技能本期未实现：正文只声明契约，不含可执行步骤；执行细节以调用它的任务书为准，禁止按本技能臆测流程。

## 用途
声明阶段、步骤、门禁与交付物的通用推进规则，作为各编排技能的共享语义。具体推进由 runner 承载，技能不重复实现。

## 何时调用
- 清单 `skills:` 白名单包含 `workflow-core`，且当前步骤需要共享的工作流语义。

## 输入 → 输出
| 输入 | 输出 |
|---|---|
| 清单 `workflows/*.yaml` | 步骤推进与门禁判定所需的通用约定 |

## 占位期行为
按调用方任务书内联执行子步骤；产物首行写 `> 占位：workflow-core 未实现（<date>）`，提交时 `--note placeholder:workflow-core`。

## 实现归属
- 未建票；实现后删除顶部占位横幅与本行。
